<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$user_id = $_SESSION['user_id'];

// Get the user's cart items
$stmt = $conn->prepare("
    SELECT inventory.item_name, inventory.price, cart.quantity, 
           (inventory.price * cart.quantity) AS total 
    FROM cart 
    JOIN inventory ON cart.id = inventory.id 
    WHERE cart.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$cartItems = [];
$totalAmount = 0;

while ($row = $result->fetch_assoc()) {
    $cartItems[] = $row;
    $totalAmount += $row['total'];
}

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Insert order into orders table
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
    $stmt->bind_param("id", $user_id, $totalAmount);
    $stmt->execute();
    $order_id = $stmt->insert_id; // Get the inserted order ID
    $stmt->close();

    // Insert each item into the order_items table
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, price, quantity, total) VALUES (?, ?, ?, ?, ?)");
    foreach ($cartItems as $item) {
        $stmt->bind_param("isddi", $order_id, $item['item_name'], $item['price'], $item['quantity'], $item['total']);
        $stmt->execute();
    }
    $stmt->close();

    // Clear the user's cart
    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();

    // Store order details in session for success page
    $_SESSION['order_details'] = $cartItems;

    // Redirect to success page
    header("Location: success.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="checkout.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <!-- Video background -->
    <div class="video-background">
        <video autoplay muted loop id="background-video">
            <source src="bg.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">MyShop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
                    <li class="nav-item"><a class="nav-link active" href="checkout.php">Checkout</a></li>
                    <li class="nav-item"><a class="nav-link" href="order_history.php">Order History</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Checkout Section -->
    <div class="container mt-5">
        <h2 class="text-center mb-4">Checkout</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Price (PHP)</th>
                    <th>Quantity</th>
                    <th>Total (PHP)</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($cartItems)): ?>
                    <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['item_name']); ?></td>
                            <td>₱<?= number_format($item['price'], 2); ?></td>
                            <td><?= htmlspecialchars($item['quantity']); ?></td>
                            <td>₱<?= number_format($item['total'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">Your cart is empty.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                    <td>₱<?= number_format($totalAmount, 2); ?></td>
                </tr>
            </tfoot>
        </table>

        <!-- Payment Form -->
        <form id="paymentForm" method="POST" action="process.php" class="text-center mt-4">
            <button type="submit" class="btn btn-success">Confirm Payment</button>
        </form>

        <a href="cart.php" class="btn btn-secondary">Back to Cart</a>
    </div>

    <!-- JavaScript -->
    <script>
        $(document).ready(function() {
            $('#paymentForm').submit(function(e) {
                e.preventDefault();

                // Display the order summary
                alert("Order placed successfully!");

                // AJAX request (optional dynamic handling)
                $.ajax({
                    type: 'POST',
                    url: 'checkout.php',
                    data: $(this).serialize(),
                    success: function() {
                        window.location.href = "payment_success.php";
                    },
                    error: function() {
                        alert('Error processing order.');
                    }
                });
            });
        });
    </script>
</body>
</html>

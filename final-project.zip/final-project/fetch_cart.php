<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'User not logged in']);
    exit();
}

include 'db.php';  // Database connection file

$user_id = $_SESSION['user_id'];

// Prepare the SQL statement to fetch cart items
$stmt = $conn->prepare("
    SELECT inventory.item_name, inventory.price, cart.quantity, 
           (inventory.price * cart.quantity) AS total
    FROM cart
    JOIN inventory ON cart.item_id = inventory.id
    WHERE cart.user_id = ?
");
$stmt->bind_param("i", $user_id);  // Binding the user ID
$stmt->execute();
$result = $stmt->get_result();

// Initialize an empty array to store cart items
$cartItems = [];

while ($row = $result->fetch_assoc()) {
    $cartItems[] = [
        'item_name' => $row['item_name'],
        'quantity' => (int)$row['quantity'],
        'price' => (float)$row['price'],
        'total' => (float)$row['total']
    ];
}

// Return cart items as JSON
echo json_encode($cartItems);
?>

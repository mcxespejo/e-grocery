<?php

session_start();
require 'C:\Users\msi\OneDrive\Desktop\System Inmtegration and Architecture\final-project\vendor\autoload.php'; // Ensure Square SDK is installed via Composer
use Square\SquareClient;
use Square\Exceptions\ApiException;
use Square\Models\CreateCheckoutRequest;
use Square\Models\Money;
use GuzzleHttp\Client;
include 'db.php';

// Insert order into order_history table (this is optional for when the order is paid)
try {
    $conn->begin_transaction();

    $stmt = $conn->prepare("INSERT INTO order_history (user_id, total_amount, created_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("id", $user_id, $totalAmount);
    $stmt->execute();
    $order_id = $conn->insert_id; // Get the last inserted order ID

    // Insert each item into order_items table
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, quantity, price) VALUES (?, ?, ?, ?)");
    foreach ($orderDetails as $item) {
        $stmt->bind_param("isid", $order_id, $item['name'], $item['quantity'], $item['amount']);
        $stmt->execute();
    }

    $conn->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $conn->rollback();
    error_log('Error saving order: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to save order']);
}

// Insert order into order_history table
try {
    $conn->begin_transaction();

    $stmt = $conn->prepare("INSERT INTO order_history (user_id, total_amount, payment_info, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("ids", $user_id, $totalAmount, $paymentInfo);
    $stmt->execute();
    $order_id = $conn->insert_id; // Get the last inserted order ID

    // Insert each item into order_items table (optional, for item-level tracking)
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, quantity, price, total) VALUES (?, ?, ?, ?, ?)");
    foreach ($orderDetails as $item) {
        $stmt->bind_param("isidd", $order_id, $item['name'], $item['quantity'], $item['price'], $item['total']);
        $stmt->execute();
    }

    $conn->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $conn->rollback();
    error_log('Error processing order: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to save order.']);
}
?>

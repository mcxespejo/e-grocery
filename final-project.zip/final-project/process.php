<?php
session_start();
include 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

$key = "your-encryption-key"; // Keep this secret and secure

// Handle Registration
if ($action === 'register') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        die("Username already exists. <a href='register.php'>Try again</a>");
    }

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();

    echo "Registration successful. <a href='index.php'>Login here</a>";
    exit();
}

// Handle Login
if ($action === 'login') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        // Decrypt the stored password
        $decrypted_password = openssl_decrypt($user['password'], "AES-128-CTR", $key, 0, "1234567891011121");

        if ($password === $decrypted_password) {
            $_SESSION['user_id'] = $user['id'];
            header("Location: dashboard.php");
        } else {
            echo "Invalid credentials";
        }
    } else {
        echo "Invalid credentials";
    }
    exit();
}

// Handle Add Item to Cart
if ($action === 'add_to_cart') {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }

    $id = $_POST['id'];  // Corrected: Using id, not id
    $quantity = $_POST['quantity'];

    // Check if the item already exists in the cart
    $stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND id = ?");
    $stmt->bind_param("ii", $_SESSION['user_id'], $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $existing_item = $result->fetch_assoc();

    if ($existing_item) {
        // Update the quantity of the existing item
        $new_quantity = $existing_item['quantity'] + $quantity;
        $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND id = ?");
        $stmt->bind_param("iii", $new_quantity, $_SESSION['user_id'], $id);
        $stmt->execute();
    } else {
        // Add a new item to the cart
        $stmt = $conn->prepare("INSERT INTO cart (user_id, id, quantity) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $_SESSION['user_id'], $id, $quantity);
        $stmt->execute();
    }

    $_SESSION['cart_message'] = "Item successfully added to the cart!";
    header("Location: dashboard.php");
    exit();
}

// Handle Logout
if ($action === 'logout') {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Handle Update Item in Inventory
if ($action === 'update_item') {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }

    $id = $_POST['id'];
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $description = $_POST['description'];

    // Update the item in the database
    $stmt = $conn->prepare("UPDATE inventory SET item_name = ?, quantity = ?, description = ? WHERE id = ?");
    $stmt->bind_param("sisi", $item_name, $quantity, $description, $id);
    $stmt->execute();

    // Redirect to the dashboard after the update
    header("Location: dashboard.php");
    exit();
}

// Handle Remove Item from Inventory
if ($action === 'remove_item') {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }

    $id = $_GET['id'];

    // Remove the item from the inventory using id (not item_name)
    $stmt = $conn->prepare("DELETE FROM inventory WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Redirect to the dashboard after removal
    header("Location: dashboard.php");
    exit();
}

// Handle Remove Item from Cart
if ($action === 'remove_from_cart') {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }

    $cart_id = $_GET['id'] ?? null;

    if ($cart_id) {
        // Remove the item from the cart based on cart.id
        $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $cart_id, $_SESSION['user_id']);
        $stmt->execute();
    }

    // Redirect to the cart page after removal
    header("Location: cart.php");
    exit();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if user is not logged in
    exit();
}

include 'db.php'; // Include the database connection

$user_id = $_SESSION['user_id'];

// Check if cart is set in the session
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: cart.php"); // Redirect to cart if no cart details are present
    exit();
}

$cartItems = $_SESSION['cart']; // Retrieve cart items from session

// Calculate total amount
$totalAmount = array_sum(array_column($cartItems, 'total'));

// Begin transaction
$conn->begin_transaction();
try {
    // Insert order details
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
    $stmt->bind_param("id", $user_id, $totalAmount);
    $stmt->execute();
    $order_id = $stmt->insert_id; // Get the newly inserted order ID
    $stmt->close();

    // Insert each item into the order_items table
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, price, quantity, total) VALUES (?, ?, ?, ?, ?)");
    foreach ($cartItems as $item) {
        $stmt->bind_param("isddi", $order_id, $item['item_name'], $item['price'], $item['quantity'], $item['total']);
        $stmt->execute();
    }
    $stmt->close();

    // Clear cart data for this user in the database if applicable
    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();

    // Commit transaction
    $conn->commit();

    // Set order details for display
    $_SESSION['order_details'] = $cartItems;

    // Clear session cart data
    unset($_SESSION['cart']);

    // Redirect to success page
    header("Location: success.php");
    exit();
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    die("Error processing order: " . $e->getMessage());
}
?>

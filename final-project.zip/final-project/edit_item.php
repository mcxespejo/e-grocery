<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'db.php';

// Get the item ID from the URL
$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();

    if (!$item) {
        die("Item not found.");
    }
} else {
    die("Invalid item ID.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Item</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="edit_item.css">
</head>
<body>
    <div class="container my-4">
        <h2 class="text-center mb-4">Edit Item</h2>

        <form action="process.php" method="POST">
            <input type="hidden" name="action" value="update_item">
            <input type="hidden" name="id" value="<?= $item['id']; ?>">

            <div class="mb-3">
                <label for="item_name" class="form-label">Item Name</label>
                <input type="text" name="item_name" class="form-control" value="<?= htmlspecialchars($item['item_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Quantity</label>
                <input type="number" name="price" class="form-control" value="<?= htmlspecialchars($item['price']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="quantity" class="form-label">Quantity</label>
                <input type="number" name="quantity" class="form-control" value="<?= htmlspecialchars($item['quantity']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($item['description']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Item</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'db.php';

$user_id = $_SESSION['user_id'];

// Fetch cart items
$stmt = $conn->prepare("
    SELECT cart.id AS cart_id, inventory.item_name AS item_name, inventory.price, cart.quantity, 
           (inventory.price * cart.quantity) AS total 
    FROM cart 
    JOIN inventory ON cart.id = inventory.id 
    WHERE cart.user_id = ?");



$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Calculate total cost
$total_cost = 0;
while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_cost += $row['total'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">MyShop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">Cart</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="checkout.php">Checkout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="order_history.php">Order History</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Video background -->
    <div class="video-background">
        <video autoplay muted loop id="background-video">
            <source src="bg.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>
    
    <div class="container mt-5">
        <h2 class="text-center mb-4">Cart</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Price (PHP)</th>
                    <th>Quantity</th>
                    <th>Total (PHP)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($cart_items)): ?>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['item_name']); ?></td>
                            <td>₱<?= number_format($item['price'], 2); ?></td>
                            <td><?= htmlspecialchars($item['quantity']); ?></td>
                            <td>₱<?= number_format($item['total'], 2); ?></td>
                            <td>
                                <a href="process.php?action=remove_from_cart&id=<?= $item['cart_id']; ?>" 
                                class="btn btn-danger btn-sm">Remove</a>
                            </td>

                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">Your cart is empty.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                    <td><strong>₱<?= number_format($total_cost, 2); ?></strong></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
        <div class="d-flex justify-content-between mt-4">
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            <a href="checkout.php" class="btn btn-success">Checkout</a>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>
        document.getElementById('checkout-button').addEventListener('click', function() {
            const orderDetails = [
                <?php
                $stmt->execute(); // Re-execute to loop through items again
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    echo "{ 
                        name: '" . addslashes($row['item_name']) . "', 
                        quantity: " . (int)$row['quantity'] . ", 
                        amount: " . ($row['price'] * 100) . ",
                        currency: 'PHP'
                    },";
                }
                ?>
            ];

            axios.post('create-checkout-session.php', { items: orderDetails })
                .then(response => {
                    const checkout_url = response.data.checkout_url;
                    window.location.href = checkout_url; // Redirect to PayMongo Checkout
                })
                .catch(error => {
                    console.error('Error creating checkout session:', error);
                    alert('Failed to initiate payment. Please try again.');
                });
        });
    </script>
     <!-- Bootstrap JS and Popper.js -->
     <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
